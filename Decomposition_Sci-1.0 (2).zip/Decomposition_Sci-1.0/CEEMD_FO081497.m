function NEW()
clc;
clear all; 
close all;
dna = fastaread('FO081497.1.fasta');
seq = dna.Sequence(7021:15020);
N = length(seq);
 cds = [928 1038 2527 2856 4113 4376 5464 5643 7254 7604];
actual_exons = zeros(1, N);
for i = 1:2:length(cds)
    actual_exons(cds(i):cds(i+1)) = 1;
end
eiip = containers.Map({'A','C','G','T'}, [0.1260, 0.1340, 0.0806, 0.1335]);
signal = zeros(1, N);
for i = 1:N
    base = upper(seq(i));
    if isKey(eiip, base)
        signal(i) = eiip(base);
    end
end
K = 351; 
M = K/3;
pad = (K-1)/2;
x_pad = [zeros(1, pad), signal, zeros(1, pad)];
STDFT = zeros(1, N);
for n = 1:N
    win = x_pad(n:n+K-1);
    STDFT(n) = abs(sum(win .* exp(-1j*2*pi*(0:K-1)*M/K)))^2;
end
S_EIIP = STDFT / max(STDFT);
imfs_emd = emd(S_EIIP(:))';
IMF1_emd = imfs_emd(1,:);
S_EMD = S_EIIP - IMF1_emd; 
S_EMD = S_EMD / max(S_EMD);
[imfs_eemd, ~] = basic_eemd(S_EIIP, 0.2, 100);
IMF1_eemd = imfs_eemd(1,:);
S_EEMD = S_EIIP - IMF1_eemd; 
S_EEMD = S_EEMD / max(S_EEMD);
[imfs_ceemd, ~] = basic_ceemd(S_EIIP, 0.2, 100);
K_imf = compute_K_by_selfcorr(imfs_ceemd);
noisy_imfs = imfs_ceemd(1:K_imf, :);
clean_imfs = imfs_ceemd(K_imf+1:end, :);
denoised_noisy = zeros(size(noisy_imfs));
for i = 1:size(noisy_imfs, 1)
    denoised_noisy(i,:) = wpt_denoise(noisy_imfs(i,:));
end
reconstructed = sum(denoised_noisy,1) + sum(clean_imfs,1);
reconstructed = reconstructed - min(reconstructed);  
S_CEEMD = reconstructed / max(abs(reconstructed));   
methods = {'STDFT','EMD','EEMD','CEEMD'};
signals = {S_EIIP, S_EMD, S_EEMD, S_CEEMD};
ymin = min(cellfun(@(x) min(x), signals));
ymax = max(cellfun(@(x) max(x), signals));
figure('Name','Output Spectra with Common Y-Axis','Position',[100 100 1200 800]);
for i = 1:4
    subplot(4,1,i); 
    plot(signals{i}, 'b', 'LineWidth', 1.2); 
    hold on;
    for j = 1:2:length(cds)
        x = [cds(j) cds(j+1) cds(j+1) cds(j)];
        y = [0 0 1 1];
        fill(x, y, 'r', 'FaceAlpha', 0.2, 'EdgeColor', 'none');
    end
    ylim([ymin ymax]); 
    title(methods{i}); 
    xlabel('Position');
    ylabel('Amplitude');
    grid on;
end

imf_sets = {imfs_emd, imfs_eemd, imfs_ceemd};
imf_titles = {'IMFs - EMD','IMFs - EEMD','IMFs - CEEMD'};
for m = 1:3
    figure('Name',imf_titles{m},'Position',[200 200 1000 600]);
    [rows, ~] = size(imf_sets{m});
    for k = 1:min(8, rows)
        subplot(8,1,k);
        plot(imf_sets{m}(k,:), 'LineWidth', 1.2);
        title(['IMF ' num2str(k)]); grid on;
    end
end

thresholds = 1:99;
metrics = struct();
comp_time = zeros(1,length(methods));

for i = 1:length(methods)
    tic; 
    y_score = signals{i};
    Sn = zeros(1,length(thresholds));
    Sp = Sn;
    F1 = Sn;
    GM = Sn;
    AC = Sn;
    CC = Sn;
    for idx = 1:length(thresholds)
        tv = thresholds(idx);
        binary_spectrum = y_score > prctile(y_score, tv);
        predicted_exons = zeros(1, length(actual_exons));
        CDS_pred = seq2CDS(binary_spectrum);
        for j = 1:2:length(CDS_pred)
            predicted_exons(CDS_pred(j):CDS_pred(j+1)) = 1;
        end
        TP = sum(predicted_exons & actual_exons);
        FP = sum(predicted_exons & ~actual_exons);
        TN = sum(~predicted_exons & ~actual_exons);
        FN = sum(~predicted_exons & actual_exons);
        Sn(idx) = TP / (TP + FN + eps);
        Sp(idx) = TN / (TN + FP + eps);
        Precision = TP / (TP + FP + eps);
        F1(idx) = 2 * (Precision * Sn(idx)) / (Precision + Sn(idx) + eps);
        GM(idx) = sqrt(Sn(idx) * Sp(idx));
        AC(idx) = (TP + TN) / (TP + TN + FP + FN + eps);
        CC(idx) = (TP*TN - FP*FN) / sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN) + eps);
    end
    [~,~,~,AUC_val] = perfcurve(actual_exons, y_score, 1);
    metrics.(methods{i}) = struct('Sn',Sn,'Sp',Sp,'F1',F1,'GM',GM,'AC',AC,'CC',CC,'AUC',AUC_val);
    comp_time(i) = toc;  
end

fields = {'F1','GM','AC','CC'};
titles = {'F1 Score','Geometric Mean','Accuracy','Correlation Coefficient'};
for f = 1:length(fields)
    figure('Name',titles{f},'Position',[300 300 800 500]); hold on;
    for i = 1:length(methods)
        plot(thresholds, metrics.(methods{i}).(fields{f}), 'LineWidth', 2, 'DisplayName', methods{i});
    end
    xlabel('Threshold (%)'); 
    ylabel(fields{f});
    title([titles{f} ' vs Threshold']);
    legend show; 
    grid on;
end
figure('Name','Sensitivity vs Specificity','Position',[300 300 700 500]);
hold on;
for i = 1:length(methods)
    m = metrics.(methods{i});
    plot(m.Sp, m.Sn, 'DisplayName', methods{i}, 'LineWidth', 2);
end
xlabel('Specificity'); 
ylabel('Sensitivity'); 
title('Sensitivity vs Specificity');
legend show; 
grid on;
figure('Name','ROC Curve','Position',[300 300 700 500]); 
hold on;
for i = 1:length(methods)
    [X,Y,~,~] = perfcurve(actual_exons, signals{i}, 1);
    plot(X,Y,'LineWidth',2,'DisplayName',methods{i});
end
xlabel('False Positive Rate');
ylabel('True Positive Rate');
title('ROC Curves'); 
legend show; 
grid on;
threshold_idx = 70;
end
function CDS = seq2CDS(sequence)
CDS = [];
i = 1;
while i <= length(sequence)
    if sequence(i) ~= 0
        start = i;
        while i <= length(sequence) && sequence(i) ~= 0
            i = i + 1;
        end
        CDS = [CDS, start, i - 1];
    end
    i = i + 1;
end
end
function [imfs_avg, res] = basic_eemd(x, noise_std, ens)
x = x(:)'; N = length(x);
all_imfs = cell(1, ens); min_imfs = inf;
for i = 1:ens
    noise = noise_std * randn(1, N);
    x_noisy = x + noise;
    imfs = emd(x_noisy);
    all_imfs{i} = imfs;
    min_imfs = min(min_imfs, size(imfs,2));
end
imfs_sum = zeros(min_imfs, N);
for i = 1:ens
    imfs_sum = imfs_sum + all_imfs{i}(:,1:min_imfs)';
end
imfs_avg = imfs_sum / ens;
res = x - sum(imfs_avg, 1);
end
function [imfs_avg, res] = basic_ceemd(x, noise_std, ens)
x = x(:)'; N = length(x);
all_imfs = {}; min_imfs = inf;
for i = 1:ens
    pos_noise = noise_std * randn(1, N);
    neg_noise = -pos_noise;
    imfs_pos = emd(x + pos_noise);
    imfs_neg = emd(x + neg_noise);
    num_imfs = min(size(imfs_pos,2), size(imfs_neg,2));
    avg_imfs = (imfs_pos(:,1:num_imfs) + imfs_neg(:,1:num_imfs)) / 2;
    all_imfs{i} = avg_imfs;
    min_imfs = min(min_imfs, num_imfs);
end
imfs_sum = zeros(min_imfs, N);
for i = 1:ens
    imfs_sum = imfs_sum + all_imfs{i}(:,1:min_imfs)';
end
imfs_avg = imfs_sum / ens;
res = x - sum(imfs_avg, 1);
end
function K = compute_K_by_selfcorr(imfs)
[num_imfs, ~] = size(imfs);
rho_vals = zeros(1, num_imfs);
for j = 2:num_imfs
    rho_vals(j) = abs(var(imfs(j,:)) / var(imfs(j-1,:)));
end
K = find(rho_vals >= 1, 1);
if isempty(K), K = floor(num_imfs/2);
end
end

function x_denoised = wpt_denoise(x)
level = 3;
wpt = wpdec(x, level, 'db4');
tn = leaves(wpt);
for i = 1:length(tn)
    c = read(wpt, 'data', tn(i));
    sigma = median(abs(c)) / 0.6745;
    thr = sigma * sqrt(2 * log(length(c)));
    c_thresh = sign(c) .* max(abs(c) - thr, 0);
    wpt = write(wpt, 'data', tn(i), c_thresh);
end
x_denoised = wprec(wpt);
end
